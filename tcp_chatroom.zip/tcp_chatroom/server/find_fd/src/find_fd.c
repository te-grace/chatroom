#include "../../include/head.h"

int find_fd(Msg *msg)
{
    sqlite3 *db;
    sqlite3_stmt *stmt;

    char **result = NULL;
    char *errmsg = NULL;
   // const char *tail;

    char sql[100];
 //   char temp[5][10];

    int i;
    //int id;
    int ret;
    int sockfd;
    int nrow;
    int cmp;
    int ncolumn;

    ret = sqlite3_open("online.db",&db);

    if(ret != SQLITE_OK)
    {
        printf("find_fd open online error!\n");
	exit(1);
    }
    memset(sql,0,sizeof(sql));

    sqlite3_get_table(db,"select * from online",&result,&nrow,&ncolumn,&errmsg);

    if(nrow != 0)
    {
        for(i = 0;i <= nrow;i++)
	{   
	    cmp = strcmp((msg->toname),result[i * ncolumn + 1]);
            //printf("cmp = %d\n",cmp);

	    if(cmp == 0)
	    {
	        sockfd = atoi(result[i * ncolumn + 2]);
		sqlite3_free_table(result);
		sqlite3_close(db);
                printf("sockfd = %d\n",sockfd);
		return sockfd;
	    }
	}
	printf("this usr is not online\n");
	return -3;
    }
    else
    {
        sqlite3_finalize(stmt);
	sqlite3_free_table(result);
	sqlite3_close(db);
	return -2;
    }
    return 0;

}
