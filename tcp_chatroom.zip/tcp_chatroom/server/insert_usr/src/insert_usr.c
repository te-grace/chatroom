#include "../../include/head.h"
void insert_usr(struct online_usr *newusr)
{
struct online_usr *first = NULL;
    newusr->next = first;
    
    first = newusr;
}
