#include "../../include/head.h"
void * read_msg(void *arg)
{
    int fd = *((int *)arg);
    int n_read;
    int w_fd;
    int to_fd;
    //int cmpp;
   // int cmpn;
    char exchange[20];
    //char buffer[1024];
    //struct online_usr *newusr= (struct online_usr)malloc(sizeof(struct online_usr));
    Msg *msg = (Msg *)malloc(sizeof(Msg));

    while(1)
    {
        memset(msg,0,sizeof(Msg));
	n_read = read(fd,msg,sizeof(Msg));

	if(n_read == -1)
	{
	    perror("read message error!\n");
	    pthread_exit(NULL);
	}
	else if(n_read == 0)
	{
	    log_del(msg);
	    printf("sockfd id %d is close!\n",fd);
	    pthread_exit(NULL);
	}
        printf("msg->fd = %d\n",msg->fd);
        printf("msg->name= %s\n",msg->name);

	printf(" action is %d\n",msg->action);
	switch(msg->action)
	{
	    case 1:
	    {  
	        
	        n_read = reg_sql(msg);

		if(n_read > 0)
		{
		    msg->action = 11;
		    if(write(fd,msg,(sizeof(Msg))) == -1)
		    {
		        perror("send buffer error!\n");
			pthread_exit(NULL);
		    }
		    printf("name = %s\n",msg->name);
		    printf(" write action is %d\n",msg->action);

		}
		else if(n_read < 0)
		{
		    msg->action = -1;
		    if(write(fd,msg,sizeof(struct message)) == -1)
		    {
		        perror("send buffer error!\n");
			pthread_exit(NULL);
		    }
		    printf("reg fail name = %s\n",msg->name);
		}
		/*else
		{
		    perror("n_read = 0")
		}*/
		break;
	    }
	    case 2:                    //登录
	    {
		n_read = log_sql(msg,fd);
		break;
	    }
	    case 3:                    //私聊
	    {
                to_fd = find_fd(msg);
		printf("to_fd = %d\n",to_fd);

		if(to_fd < 0)
		{
		    msg->action = -3;
		    write(fd,msg,(sizeof(Msg)));
		}
		else
		{
		    msg->action = 13;
                    strcpy(exchange, msg->toname);
		    strcpy(msg->toname,msg->name);
		    strcpy(msg->name,exchange);
		    w_fd = write(to_fd,msg,sizeof(Msg));
		    if(w_fd == -1)
		    {
		        perror("write msg->msg error\n");
			pthread_exit(NULL);
		    }
		}
		break;
	    }
	    case 4:
	    {
                to_fd = find_fd(msg);
		printf("to_fd = %d\n",to_fd);

		if(to_fd < 0)
		
		{
		    msg->action = -4;
		    write(fd,msg,(sizeof(Msg)));
		}
		else
		{
		    msg->action = 14;
                    strcpy(exchange, msg->toname);
		    strcpy(msg->toname,msg->name);
		    strcpy(msg->name,exchange);
		    w_fd = write(to_fd,msg,sizeof(Msg));
		    if(w_fd == -1)
		    {
		        perror("write msg->msg error\n");
			pthread_exit(NULL);
		    }
		}
		break;

	    }
	    case ADMIN:                                                        //管理员登录
	    {
		n_read = log_sql(msg,fd);
	        msg->action = 17;
		
		break;
	    }
	    case 20:
	    {
	        log_del(msg);
	        printf("sockfd id %d is close!\n",fd);
	        pthread_exit(NULL);
		msg->action = 120;
		write(fd,msg,sizeof(Msg));
		break;
	    }
	    case 21:
	    {
	        on_sqlite(msg);
		msg->action = 121;
		write(fd,msg,sizeof(Msg));
		break;
	    }
	    case 50:                                             //管理员踢人下线
	    {
	        //admin_kick(msg);
		msg->action = 150;
		printf("%s kick success\n",msg->name);
		break;
	    }
	    case 51:                                              //管理员禁言
	    {
	        admin_forbid(msg);
		msg->action = 151;
		printf("%s forbid success\n",msg->toname);
		break;
	    }
	    case 52:                                             //管理员解禁言
	    {
	        break;
	    }

	}
    }
}

int main()
{
    //int nrow;
    //int ncolumn;
    //int n_read;
    int sockfd;
    int new_fd;
   
    unsigned int sin_size;
    int opt = 1;

    //char sql;
    //char *errmsg;
    //char **result;
    
    pthread_t id;

    struct sockaddr_in serveraddr;
    struct sockaddr_in cliaddr;

    //sqlite3 *db;

    //Msg *msg = (Msg *)malloc(sizeof(Msg));

    if((sockfd = socket(AF_INET,SOCK_STREAM,0)) == -1)
    {
        printf("server socket error!\n");
	exit(1);
    }

    bzero(&serveraddr,sizeof(serveraddr));
    serveraddr.sin_family = AF_INET;
    serveraddr.sin_addr.s_addr = htonl(INADDR_ANY);
    serveraddr.sin_port = htons(8888);

    setsockopt(sockfd,SOL_SOCKET,SO_REUSEADDR,&opt,sizeof(opt));

    if(bind(sockfd,(struct sockaddr *)&serveraddr,sizeof(serveraddr)) == -1)
    {
        printf("bind error!\n");
	exit(1);
    }

    if(listen(sockfd,5) == -1)
    {
        printf("listen error!\n");
	exit(1);
    }
    
    while(1)
    {
        sin_size = sizeof(struct sockaddr_in);

	if((new_fd = (accept(sockfd,(struct sockaddr *)&cliaddr,&sin_size))) == -1)
	{
	    printf("accept error!\n");
	    exit(1);
	}
	fprintf(stderr,"Server get connect from %s\n",inet_ntoa(cliaddr.sin_addr));  //将网络地址转换为点分十进制格式
        
	printf("new_fd = %d",new_fd);
	pthread_create(&id,NULL,read_msg,(void *)&new_fd);

    }
    return 0;
}
