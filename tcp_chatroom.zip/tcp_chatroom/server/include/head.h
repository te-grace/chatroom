#ifndef _HEAD_H_
#define _HEAD_H_

#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>
#include <netdb.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/socket.h>
#include <string.h>
#include <arpa/inet.h>
#include <sqlite3.h>
#include <errno.h>
#include <curses.h>
#include <time.h>

enum
{
    EXIT = 0,
    LOG,
    REG,
    NAME,
    PASSWORD,
    TONAME,
    TOGROUP,
    ADMIN,
    HELP,
    FORBID = 31,  
    RELIEVE,
    KICK
};
struct message
{
    int id;
    int fd;
    int flag;
    int action;
    int way;
    char name[20];
    char on_name[5][20];
    char pwd[20];
    char toname[20];
    char msg[1024];
};
typedef struct message Msg;
/*
struct online_usr
{
    int fd;
    int id;
    char name[20];
    char pwd[20];

    struct online_usr *next;
};
*/
  //  struct online_usr *first;
extern int reg_sql(Msg *msg);
//extern int log_sql(Msg *msg);
extern int log_del(Msg *msg);
//extern void insert_usr(struct online_usr *newusr);
extern int find_fd(Msg *msg);

#endif
