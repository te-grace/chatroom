#include "../../include/head.h"

int admin_forbid(Msg *msg)
{
    int ncolumn;
    int nrow;
    int ret;
    int cmp;
    int i;

    sqlite3 *pdb;
    
    char **result = NULL;
    char *errmsg = NULL;

    char sql[100];

    ret = sqlite3_open("online.db",&pdb);

    if(ret != SQLITE_OK)
    {
        printf("admin_forbid sqlite open error!\n");
	exit(1);
    }

    memset(sql,0,sizeof(sql));

    sqlite3_get_table(pdb,"select * from online",&result,&nrow,&ncolumn,&errmsg);;

    if(nrow != 0)
    {
        for(i = 1;i <= nrow;i++)
	{
	    cmp = strcmp((msg->toname),result[i * ncolumn + 1]);
	    if(cmp == 0)
	    {
	        sprintf(sql,"update online set flag = %d where name = msg->toname",~(msg->flag));
		sqlite3_free_table(result);
		sqlite3_close(pdb);
		
		return 0;
	    }

	}
    }
    

}
