#include "../../include/head.h"

int admin_kick(Msg *msg)
{
    int ret;
    
    sqlite3_stmt *stmt;
    sqlite3 *pdb;

    char *errmsg = NULL;
  //  const char *tail;
    char sql[100];

    ret = sqlite3_open("online.db",&pdb);

    if(ret != SQLITE_OK)
    {
        printf("online.db open error!\n");
	exit(1);
    }

    /*清空数据库*/
    memset(sql,0,sizeof(sql));
    sprintf(sql,"delete from online where name = '%s';",(msg->name));
/*
    if(ret != SQLITE_OK)
    {
        fprintf(stderr,"SQL error:%s\n",sqlite3_errmsg(pdb));
    }
*/
    sqlite3_exec(pdb,sql,NULL,NULL,&errmsg);
    sqlite3_close(pdb);

    return 0;
}
