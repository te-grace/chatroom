#include "../../include/head.h"

int on_sqlite(Msg *msg)
{
    sqlite3 *db ;
    sqlite3_stmt *stmt;
    char **result = NULL;
    char *errmsg = NULL;
    const char *tail;

    char sql[100];
  //  char temp[3][50];
   
    int i;
    int id;
    int nrow;     //行
    int ncolumn;  //列

    int ret = sqlite3_open("online.db",&db);

    if(ret != SQLITE_OK)
    {
    	printf("sqlite open error!\n");
	exit(1);
    }

    memset(sql,0,sizeof(sql));
  //  memset(msg->on_name,0,sizeof(msg->on_name));

    sqlite3_get_table(db,"select * from online",&result,&nrow,&ncolumn,&errmsg);
    if(nrow != 0)
    {
    	for(i = 1;i <= nrow;i++)      // 行数
	{
	    strcpy((msg->on_name)[i],result[i * ncolumn + 1]);  //比较行的第几列
	//    strcpy(temp[2],result[i * ncolumn + 2]);
	}
	sqlite3_free_table(result);
	sqlite3_close(db);
	return 3;
    }
    else
    {
    //	msg->action = 404;

	sqlite3_free_table(result);
	sqlite3_close(db);

	return -1;
    }

}
