#include "../../include/head.h"

int log_sql(Msg *msg,int fd)
{
    int i;
    int ret;
    int ret2;
    int ret3;
    int nrow;
    int ncolumn;
    
//    struct online_usr *newusr;

    sqlite3 *pdb;
    sqlite3 *db;

    time_t t;

    char **result = NULL;
    char *errmsg = NULL;

    char sql[100];
    
    srand((unsigned)time(&t));
    ret = sqlite3_open("reg.db",&pdb);
    
    if(ret != SQLITE_OK)
    {
        printf("sqlite open error!\n");
	exit(1);
    }

    /*清空数据库*/
    memset(sql,0,sizeof(sql));
    
    sqlite3_get_table(pdb,"select *from reg_usr",&result,&nrow,&ncolumn,&errmsg);
    
    if(nrow != 0)
    {
        for(i = 1; i <= nrow; i++)
	{
	    ret = strcmp(msg->name,result[i * ncolumn + 1]);
	    if(ret == 0)
	    {
	       // strcpy((msg->toname),msg->name);
		ret2 = strcmp(msg->pwd,result[i * ncolumn + 2]);
		    if(ret2 == 0)
		    {
                        sqlite3_close(pdb);

			goto loop;
/*
			newusr = (struct online_usr *)malloc(sizeof(struct online_usr));
			newusr->fd = fd;
			
			insert_usr(newusr);
			msg->action = 12;
			write(fd,msg,sizeof(Msg));
                                
                        sqlite3_close(pdb);
			return 12;*/
			/*
			ret3 = sqlite3_open("online.db",&db);
			if(ret3 != SQLITE_OK)
			{
			    perror("online db open error!\n");
                            exit(1);
			}
                        sprintf(sql,"insert into online (id,name)values(%d,'%s')",(msg->id),(msg->name));    
			sqlite3_exec(db,sql,NULL,NULL,&errmsg);
                        sqlite3_close(db);
			return 4;
			*/
		    }
		    else
		    {
			msg->action = -2;
			write(fd,msg,sizeof(Msg));
			sqlite3_close(pdb);
        		printf("login error!wrong1 password or user not exist\n");
			return -2;
		    } 
	     }
	}
	msg->action = -2;
	write(fd,msg,sizeof(Msg));
	sqlite3_close(pdb);
        printf("login error!wrong2 password or user not exist\n");
	return -2;
    }
loop:		
			
    			memset(sql,0,sizeof(sql));
			ret3 = sqlite3_open("online.db",&db);
			if(ret3 != SQLITE_OK)
			{
			    perror("online db open error!\n");
                            exit(1);
			}
			msg->flag = 0;
                        sprintf(sql,"insert into online(id,name,fd,flag) values(%d,'%s',%d,%d)",(msg->id),(msg->name),(fd),(msg->flag));
			sqlite3_exec(db,sql,NULL,NULL,&errmsg);
                        sqlite3_close(db);

                        //on_sqlite(msg);

		        msg->action = 12;
			printf("send action = %d\n",msg->action);
			write(fd,msg,sizeof(Msg));
			
			return 4;
}
