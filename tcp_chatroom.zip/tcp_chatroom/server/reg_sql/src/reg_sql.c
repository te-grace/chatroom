#include "../../include/head.h"

int reg_sql(Msg *msg)
{
    int ret;
    //int id;
    //int nrow;
    //int ncolumn;

    sqlite3 *pdb;
    sqlite3_stmt *stmt;

    time_t t;

    //char **result = NULL;
    char *errmsg = NULL;
    const char *tail;

    char sql[100];
    
    srand((unsigned)time(&t));
    ret = sqlite3_open("reg.db",&pdb);
    
    if(ret != SQLITE_OK)
    {
        printf("sqlite open error!\n");
	exit(1);
    }

    /*清空数据库*/
    memset(sql,0,sizeof(sql));

    sprintf(sql,"select * from reg_usr where name = '%s';",msg->name);
    ret = sqlite3_prepare(pdb,sql,strlen(sql),&stmt,&tail);

    if(ret != SQLITE_OK)
    {
        fprintf(stderr,"SQL error:%s\n",sqlite3_errmsg(pdb));
    }
     
    /*检测重名*/ 
    ret = sqlite3_step(stmt);                                     //按行搜索是否重名 
    sqlite3_column_count(stmt);
    while(ret == SQLITE_ROW)
    {
        ret = sqlite3_step(stmt);
	sqlite3_finalize(stmt);

	sqlite3_close(pdb);
	return -3;                                               //重名的错误返回  -3
    }
    
    msg->id = rand();

    memset(sql,0,sizeof(sql));
    sprintf(sql,"insert into reg_usr(id,name,password)values(%d,'%s','%s')",(msg->id),msg->name,msg->pwd);//格式化输入
    //printf("sql id is :%d\n",(msg->id));

    sqlite3_exec(pdb,sql,NULL,NULL,&errmsg);
    sqlite3_finalize(stmt);
    sqlite3_close(pdb);
    
    return 3;
}
