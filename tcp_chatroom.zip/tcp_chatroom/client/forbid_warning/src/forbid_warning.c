#include "../../include/head.h"

int forbid_warning()
{
    WINDOW *warning;

    initscr();
    refresh();

    warning = newwin(15,40,7,40);
    box(warning,0,0);
    mvwaddstr(warning,5,13,"sorry!");
    mvwaddstr(warning,7,3,"You have been banned speaking");
    mvwaddstr(warning,9,10,"please wait for ADMIN reliving");
    
    wrefresh(warning);
    sleep(3);
    delwin(warning);

    endwin();
    
    return 0;
}
