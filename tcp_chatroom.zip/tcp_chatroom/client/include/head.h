#ifndef _HEAD_H_
#define _HEAD_H_

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <netdb.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/socket.h>
#include <pthread.h>
#include <arpa/inet.h>
#include <sqlite3.h>
#include <errno.h>
#include <curses.h>
#include <time.h>

enum
{
    EXIT = 0,
    LOG,
    REG,
    NAME,
    PASSWORD,
    TONAME,
    TOGROUP,
    ADMIN,
    HELP,
    FORBID = 31,
    RELIEVE,
    KICK
};
struct message
{
    int id;
    int fd;
  //  int socket;
    int flag;
    int action;
    int way;
    char name[20];
    char on_name[5][20];
    char pwd[20];
    char toname[20];
    char msg[1024];
};
/*
struct online_usr
{
    int fd;
    int id;
    char name[20];
    char pwd[20];

    struct online_usr *next;

};
*/
extern int menu();
extern int pass_check();
extern int reg_sus();
extern int reg_fail();
typedef struct message Msg;

#endif
