#include "../../include/head.h"

int reg_sus(Msg *msg)
{
    WINDOW *reg_s;
    
    //char id[2];
    initscr();
    refresh();
    
    reg_s = newwin(10,40,11,40);
    box(reg_s,0,0);
    mvwaddstr(reg_s,3,10,"register success!");
    mvwaddstr(reg_s,5,10,"your id is:");
    mvwprintw(reg_s,7,10,"%d",msg->id);
    wrefresh(reg_s);
    sleep(3);
    delwin(reg_s);
    endwin();

    return 0;
}
