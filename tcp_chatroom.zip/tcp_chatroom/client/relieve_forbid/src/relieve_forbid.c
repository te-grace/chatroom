#include "../../include/head.h"

int relieve_forbid()
{
    WINDOW *relieve;

    initscr();
    refresh();

    relieve = newwin(15,40,7,40);
    box(relieve,0,0);
    mvwaddstr(relieve,6,10,"Congratulations!");
    mvwaddstr(relieve,8,8,"You have been relieved");
    
    wrefresh(relieve);
    sleep(3);
    delwin(relieve);

    endwin();
    
    return 0;
}
