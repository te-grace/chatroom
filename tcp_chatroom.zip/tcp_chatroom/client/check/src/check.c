#include "../../include/head.h"

int pass_check(int sockfd,Msg *msg,int cmd)
{
    struct online_usr *first = NULL;
   // int cmd;
    char check[10];
    
    //printf("a  %d,%s,%s\n",sockfd,msg->name,msg->pwd);
    //sleep(3);
    //msg = (Msg *)malloc(sizeof(Msg));
    //memset(msg,0,sizeof(Msg));

    //cmd = menu(msg);
    while(1)
    {
	    switch(cmd)
	    {
	        case EXIT:
		{
		    
		    exit(1);

		}
		case REG:
		{
                    msg->action = 1; 
		   // setbuf(stdin,NULL);
                    write(sockfd,msg,sizeof(Msg));
		    //printf("%d,%s,%s\n",sockfd,msg->name,msg->pwd);	
                    
		    return 0;
		}

		case LOG:
		{
		    msg->action = 2;
                    msg->flag = 0;
		    write(sockfd,msg,sizeof(Msg));
	            
		    return 0;
		    		   
		}
		case ADMIN:
		{
		    msg->action = ADMIN;
		    write(sockfd,msg,sizeof(Msg));
		    
		    return 0;
		}
	    }
//	}
    }

    return 0;
}
