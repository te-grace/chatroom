#include "../../include/head.h"

#define MAX_LEN 20

int get_input(WINDOW *subwin,char *str,int mark,int row,int col)
{
    int i = 0;
    int ch;

    cbreak();
    keypad(subwin,TRUE);
    wmove(subwin,row,col);

    if(mark == PASSWORD)
    {
        noecho();
    }
    else
    {
        echo();
    }

    while((ch = wgetch(subwin)) != '\n' && i < MAX_LEN - 2)
    {
        if(ch != KEY_BACKSPACE)
	{
	    str[i++] = ch;

	    if(mark == PASSWORD)
	    {
	        waddch(subwin,'*');
	    }
	}
	else
	{
	    if(i > 0)
	    {
	        str[--i] = '\0';
		mvwaddch(subwin,row,col + i,' ');
		wmove(subwin,row,col + i);
	    }
	}
    }
    str[i] = '\0';

    //printw("str = %s",str);
    //refresh();
    //sleep(3);

    return i;
}

int  menu(Msg  *msg)
{
    WINDOW *reg_log;
    WINDOW *reg;
    WINDOW *pwdwin;
    WINDOW *namewin;

    int x;
    int y;
    int c;
    int ch;
    int get_reg;
    int get_log;

    char psw[MAX_LEN] = {0};
    
    //msg = (Msg *)malloc(sizeof(Msg));
    //memset(msg,0,sizeof(Msg));

    initscr();
    noecho();
    keypad(stdscr,TRUE);
    refresh();

    reg_log = newwin(20,57,5,30);
    box(reg_log,0,0);
    mvwaddstr(reg_log,1,20,"chat room 3.0");
    mvwaddstr(reg_log,4,15,"LOG_IN");
    mvwaddstr(reg_log,4,35,"REGISTER" );
    mvwaddstr(reg_log,1,56,"X");

    mvwaddch(reg_log,4,13,ACS_DIAMOND);
    wmove(reg_log,4,28);

    wrefresh(reg_log);
    keypad(reg_log,TRUE);                       //方向键等特殊键可以被识别
    
    curs_set(FALSE);

    while(1)
    {
        ch = wgetch(reg_log);
	switch(ch)
	{
	    case KEY_LEFT:
	    {
	        mvwaddch(reg_log,4,33,' ');
		mvwaddch(reg_log,4,13,ACS_DIAMOND);
		msg->way = LOG;
		break;
	    }
	    case KEY_RIGHT:	
	    {
	        mvwaddch(reg_log,4,13,' ');
		mvwaddch(reg_log,4,33,ACS_DIAMOND);
		msg->way = REG;
		break;
	    }
	    case KEY_UP:
	    {
	        wmove(reg_log,1,56);
		c = getch();

		if(c == '\n')
		{
		    return EXIT;
		}

	    }
	}
	if(ch == '\n')
	{
	    if(msg->way == REG)
	    {
		reg = derwin(reg_log,3,30,13,10);
		box(reg,0,0);
		mvwaddstr(reg,1,1,"password:");

		wrefresh(reg);
	    }
	    wrefresh(reg_log);
	    break;
	}
    }
    curs_set(TRUE);
    
    namewin = derwin(reg_log,3,30,7,10);
    box(namewin,0,0);
    mvwaddstr(namewin,1,1,"name:");

    pwdwin = derwin(reg_log,3,30,10,10);
    box(pwdwin,0,0);
    mvwaddstr(pwdwin,1,1,"password:");
    wmove(pwdwin,1,13);

    wrefresh(namewin);
    wrefresh(pwdwin);
    wrefresh(reg_log);

    get_input(namewin,msg->name,NAME,1,6);
    /*
    if((msg->name) == "admin")
    {
        get_log = wgetch(pwdwin);
        if(get_log == '\n')
        {      
            wclear(reg_log);
            delwin(reg_log);
            delwin(reg); 
	    delwin(namewin);
            delwin(pwdwin);
	    wrefresh(reg_log);
            refresh();
            endwin();
	    system("clear");
            return ADMIN;
        }
            
    }
    */
    get_input(pwdwin,msg->pwd,PASSWORD,1,10);
    
    if(msg->way == REG)
    {
        ch = get_input(reg,psw,PASSWORD,1,10);

        //mvwaddstr(reg_log,3,9,msg->name);
        wrefresh(reg_log);

    //get_input(reg,Msg->pwd,PASSWORD,1,10);
    //printw("msg->name = %s ",msg->name);
    //printw("msg->pwd = %s ",msg->pwd);
    //refresh();
	if((strcmp(msg->pwd,psw)) != 0)
	{
	    while(ch)
	    {
	        wmove(reg,1,11+ch - 1);
		mvwaddch(reg,1,11 + ch - 1,' ');

		ch--;
	    }
	    memset(psw,0,sizeof(psw));
	}
	get_reg = wgetch(reg);
        if(get_reg == '\n')
	{
	    
	    delwin(reg_log);
            delwin(reg);
            delwin(namewin);
            delwin(pwdwin);
	    refresh();

            endwin();
	    
	    return REG;
	}
    }
    //printw("msg->name = %s\n ",msg->name);
    //printw("msg->pwd = %s ",msg->pwd);
    //refresh();
    //sleep(3);
    
    get_log = wgetch(pwdwin);
    if(get_log == '\n')
    {      
        wclear(reg_log);
        delwin(reg_log);
        delwin(reg); 
	delwin(namewin);
        delwin(pwdwin);
	wrefresh(reg_log);
        refresh();
        endwin();
	system("clear");
	if((msg->name) == "admin")
	{
	    return ADMIN;
	}
        return LOG;
    }
}
