#include "../../include/head.h"

int kicked(Msg *msg)
{
    WINDOW *remind;

    remind = newwin(5,30,5,45);
    box(remind,0,0);
    mvwaddstr(remind,2,3,"SORRY!");
    mvwaddstr(remind,3,3,"You have been kicked off,");
    mvwaddstr(remind,2,4,"please login again");
    wrefresh(remind);
    sleep(5);
    
    delwin(remind);
    endwin();

    menu();

    return 0;
}
