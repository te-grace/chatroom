#include "../../include/head.h"

int off_line()
{
    WINDOW *offline;

    initscr();
    refresh();

    offline = newwin(15,40,7,40);
    box(offline,0,0);
    mvwaddstr(offline,5,13,"OFFLINE SUCCESS!");
    mvwaddstr(offline,7,13,"Thank you for using!");
    
    wrefresh(offline);
    sleep(3);
    delwin(offline);

    endwin();
    
    return 0;
}
