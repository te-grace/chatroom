#include "../../include/head.h"

int new_msg(int fd,struct message *msg)//,struct online_usr **first)
{
    int i = 1;
    int x;
    int y;
    int ch;
    int ret;
    int c;
    
    WINDOW *in_line;
    WINDOW *head_p;
    
    initscr();
    keypad(stdscr,TRUE);
    refresh();

    in_line = newwin(25,23,1,90);
    box(in_line,0,0);
    mvwaddstr(in_line,3,13,msg->name);
    mvwaddstr(in_line,6,1,"Online Friend:");   
    mvwaddstr(in_line,7,1,"NEW MESSAGE!!!");   
    refresh();

    head_p = derwin(in_line,4,9,2,2);
    box(head_p,0,0);
    mvwaddstr(head_p,1,2,">");
    mvwaddstr(head_p,2,4,"^");
    mvwaddstr(head_p,1,6,"<");
    
    wrefresh(in_line);
    wrefresh(head_p);

    move(7,91);
    x = 7;
    y = 91;
    refresh();
    while(1)
    {
        ch = getch();
        
	switch(ch)
	{
	    case KEY_DOWN:
	    {
	        x = x + 1;
		move(x,y);
		c = getch();
		if(c == '\n')
		{
		    chatwin_recv(fd,msg);
		}
	    }
	    case '\n':
	    {
	        log_sus(fd,msg);
		refresh(); 
	    	msg->action = 21;
	    	ret = write(fd,msg,sizeof(Msg));
	    
	    	if(ret == -1)
	    	{
	            perror("  -1 write error!\n");
                    sleep(3);
	    	}
	    	wclear(in_line);
	    	wclear(head_p);
    	    	delwin(in_line);
    	    	delwin(head_p);

            	refresh();
            	endwin();

	    	return 0;
	    }
	}
        
    }
   // refresh();
    //sleep(3);

    //delwin(in_line);
   // delwin(head_p);

    refresh();
  //  endwin();
//    while(1);
    return 0;
}
