#include "../../include/head.h"

int adminwin(int fd,struct message *msg)//,struct online_usr **first)
{
    int i = 1;
    int x;                         //在线用户窗口行控制
    int y;                         //在线用户窗口列控制
    int ch;                        //在线用户窗口输入获得
    int xe;                        //管理员权限窗口行控制
    int ye;                        //管理员权限窗口列控制
    int c;                         //管理员权限窗口输入获得
    //first = NULL;
   // struct online_usr *temp = *first;
    
    WINDOW *adwin;
    WINDOW *head_p;
    WINDOW *user;
    WINDOW *operate;

    initscr();
    keypad(stdscr,TRUE);
    refresh();

    adwin = newwin(25,23,1,90);
    box(adwin,0,0);
    mvwaddstr(adwin,3,13,"ADMIN");
    mvwaddstr(adwin,6,1,"Online user:");
/*
    for(i = 1;i < 6;i++)
    {
	mvwprintw(in_line,i+8,1,"%s",msg->on_name);
	wrefresh(in_line);
    }
*/    
    head_p = derwin(adwin,4,9,2,2);
    box(head_p,0,0);
    mvwaddstr(head_p,1,2,"^ ^ /");
    mvwaddstr(head_p,2,4,".");
    mvwaddstr(head_p,1,7,ACS_DIAMOND);
    wrefresh(adwin);
    wrefresh(head_p);

    user = derwin(adwin,15,23,7,0);
    box(user,0,0);
    wrefresh(user);
    move(7,91);
    x = 7;
    y = 91;
    
    //touchwin(in_line);
    refresh();
    for(i = 1;i < 6;i++)
    {
	mvwprintw(user,i,1,"%s",(msg->on_name)[i]);
	wrefresh(user);
    }
    refresh();

    touchwin(user);
    while(1)
    {
        touchwin(user);
        ch = getch();
            switch(ch)
	    {
	        case KEY_UP:
	        {
                    move(x-1,y);
		    x = x - 1;
		    refresh();
		    break;
	        }
	        case KEY_DOWN:
	        {
	            move(x+1,y);
		    x = x + 1;
		    refresh();
		    break;
	        }
	        case '\n':
	        {
		    operate = newwin(10,23,5,60);
		    box(operate,0,0);
		    mvwaddstr(operate,2,3,"OPERATE:");
		    mvwaddstr(operate,4,3,"FORBID");
		    mvwaddstr(operate,6,3,"RELIEVE");
		    mvwaddstr(operate,8,3,"KICK USER");
		    wrefresh(operate);

                    move(7,62);
		    xe = 7;
		    ye = 62;
		    c = getch();
                    switch(c)
		    {
		        case KEY_DOWN:
			{
		            xe += 2;
                            move(xe,ye);
			    refresh();
			    break;
			}
			case KEY_UP:
			{
			    xe -= 2;
			    move(xe,ye);
			    refresh();
			    break;
			}
			case '\n':
			{
			    if(xe == 9)
			    {
			        return FORBID;
			    }
			    else if(xe == 11)
			    {
			        return RELIEVE;
			    }
			    else if(xe == 13)
			    {
			        return KICK;
			    }
			}
		    }

		    break;
	        }
	    }
        
    }


    refresh();
    return 0;
}
