#include "../../include/head.h"

int  reg_fail()
{
    WINDOW *reg_f;

    initscr();
    refresh();

    reg_f = newwin(13,40,8,40);
    box(reg_f,0,0);
    mvwaddstr(reg_f,3,10,"register fail!");
    mvwaddstr(reg_f,7,10,"  used name");
    mvwaddstr(reg_f,9,7,"please register again");
    wrefresh(reg_f);
    sleep(3);
    delwin(reg_f);
    endwin();
    
    return 0;
}
