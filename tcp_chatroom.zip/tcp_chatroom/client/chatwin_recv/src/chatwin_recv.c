#include "../../include/head.h"

int chatwin_recv(int fd,struct message *msg)
{
    int i;
    int x;
    int y;
    int ch;
    int len;
/*
    char str[20][20] = {" > y <","(T _ T)","(#> & <#)","(O A O)|||","m(. _ .)m( (_ _) )","(^ _ ^)/(T _ T)"};
*/
    WINDOW *chatwin;     //主聊天框
    WINDOW *w_msg;       //写内容框
    WINDOW *r_msg;       //读信息框
    WINDOW *express;     //表情框
    WINDOW *Exit;        //退出按钮
    WINDOW *Enter;       //发送按钮
    /*
    WINDOW *sad;         //伤心表情     
    WINDOW *happy;       //开心表情
    WINDOW *mad;         //生气表情
    WINDOW *surprise;    //惊讶表情
    WINDOW *apologize;   //道歉
    WINDOW *comfort;     //安慰
*/
    struct tm *local;
    time_t t;
    t = time(NULL);
    local = localtime(&t);
    
    initscr();
    refresh();
    keypad(stdscr,TRUE);

    curs_set(TRUE);

    chatwin = newwin(20,57,5,20);
    box(chatwin,0,0);
    mvwaddstr(chatwin,1,1,msg->toname);
    
    move(16,21);
    y = 21;
    x = 16;

    r_msg = derwin(chatwin,8,57,3,0);        //r_msg框8行57列，起始位置相对于chatwin框的3行1列
    box(r_msg,0,0);
    scrollok(r_msg,TRUE);
    
    w_msg = derwin(chatwin,8,57,10,0);
    box(w_msg,0,0);

    express = derwin(chatwin,3,21,17,0);
    box(express,0,0);
    mvwaddstr(express,1,5,"EXPRESSION");

    Enter = derwin(chatwin,3,21,17,20);
    box(Enter,0,0);
    mvwaddstr(Enter,1,8,"SEND");

    Exit = derwin(chatwin,3,17,17,40);
    box(Exit,0,0);
    mvwaddstr(Exit,1,7,"EXIT");

    wrefresh(chatwin);
    wrefresh(r_msg);
    wrefresh(w_msg);
    wrefresh(express);
    wrefresh(Enter);
    wrefresh(Exit);
    refresh();
    
    mvwprintw(r_msg,1,20,"%d : %d : %d",local->tm_hour,local->tm_min,local->tm_sec);
    mvwaddstr(r_msg,2,3,msg->msg);
    wrefresh(r_msg);
    wrefresh(chatwin);
    refresh();
    touchwin(r_msg);
    touchwin(chatwin);

    while(1)
    {
	{
	    if((y == 21) && (x == 16))        // 光标在输入框中
	    {
		    touchwin(w_msg);
		    echo();

		    mvwgetstr(w_msg,1,1,msg->msg);    //stdscr 16,21
		    wrefresh(w_msg);
		    touchwin(chatwin);
      		    ch = getch();
	        switch(ch)
		{
		    case KEY_DOWN:
		    {
		        move(23,35);
			x = 23;
			y = 35;
			refresh();
			break;
		    }
		    case KEY_RIGHT:
		    {
		        move(23,52);
			x = 23;
			y = 52;
			refresh();
			break;
		    }
		}
	    }
	    else if((y == 35) && (x == 23))         //光标在表情框中
	    {
      		ch = getch();
	        switch(ch)
		{
		    case KEY_UP:
		    {
		        move(16,21);
			x = 16;
			y = 21;
			refresh();
			break;
		    }
		    case KEY_RIGHT:
		    {
		        move(23,52);
			x = 23;
			y = 52;
			refresh();
			break;
		    }
		    
		}
	    	if(ch == '\n')
	    	{
		    chat_e(fd,msg);	
	        }
	    }
	    else if((y == 52) && (x == 23))      //光标在发送框中
	    {
      		ch = getch();
	        switch(ch)
		{
		    case KEY_LEFT:
		    {
		        move(23,35);
			x = 23;
			y = 35;
			refresh();
			break;
		    }
		    case KEY_RIGHT:
		    {
		        move(23,71);
			x = 23;
			y = 71;
			refresh();
			break;
		    }
		    case KEY_UP:
		    {
		        move(16,21);
			x = 16;
			y = 21;
			refresh();
			break;
		    }
		}    
		while(ch == '\n')
		{
		    if((msg->msg) != '\0')
		    {
		        int mm = 0;
		        msg->action = 4;
			msg->fd = fd;
		        mm = write(fd,msg,sizeof(Msg));

		        if(mm == -1)
		        {
		            perror("send error!\n");
			    pthread_exit(NULL);
		        }
			touchwin(r_msg);
			mvwprintw(r_msg,3,20,"%d : %d : %d",local->tm_hour,local->tm_min,local->tm_sec);
			mvwprintw(r_msg,4,46-strlen(msg->msg),"%s",msg->msg);
			len = strlen(msg->msg);
			for(i = 0;i < len;i++)
			{
			    mvwprintw(w_msg,1,i + 1," ");
			}
			touchwin(w_msg);
			wrefresh(r_msg);
			refresh();
			move(16,21);
			break;
                    }  
		}
	    }
	    else if((y == 71) && (x == 23))        //光标在退出框中
	    {
      		ch = getch();
	        switch(ch)
		{
		    case KEY_LEFT:
		    {
		        move(23,52);
			x = 23;
			y = 52;
			refresh();
			break;
		    }

		    case KEY_UP:
		    {
		        move(16,21);
			x = 16;
			y = 21;
			refresh();
			break;
		    }
		}
		while(ch == '\n')
		{
		    wclear(chatwin);
		    wrefresh(chatwin);
                    delwin(chatwin);
                    delwin(r_msg);
                    delwin(w_msg);
                    delwin(express);
                    delwin(Enter);
                    delwin(Exit);

		    refresh();

		    return 0;
		}
	    }
	}
    }	

    delwin(chatwin);
    delwin(r_msg);
    delwin(w_msg);
    delwin(express);
    delwin(Enter);
    delwin(Exit);
    refresh();
    endwin();

    return 0;

}
