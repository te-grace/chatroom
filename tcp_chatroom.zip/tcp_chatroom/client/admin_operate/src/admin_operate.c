#include "../../include/head.h"

int admin_operate(Msg *msg,int fd)
{
    int operation;

    operation = adminwin(fd,msg);
    
    if((operation != FORBID) && (operation == RELIEVE) && (operation == KICK))
    {
        perror("operation receive error!\n");
	
	return 0;
    }
    if(operation == FORBID)
    {
        msg->action = 51;
	msg->flag = 1;
	write(fd,msg,sizeof(Msg));
    }
    else if(operation == RELIEVE)
    {
        msg->action = 52;
	msg->flag = 0;
	write(fd,msg,sizeof(Msg));
    }
    else
    {
        msg->action = 50;
	write(fd,msg,sizeof(Msg));
    }
    return 0;
}
