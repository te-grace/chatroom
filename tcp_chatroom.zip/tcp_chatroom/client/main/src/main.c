#include "../../include/head.h"

#define portnumber 8888
void  *recv_msg(void *arg)
{
    int fd = *((int *)arg);
    int n_recv;
    int cmd;

    Msg *msg;
  
    msg = (Msg *)malloc(sizeof(Msg));
    
    while(1)
    {
        memset(msg,0,sizeof(Msg));
	n_recv = read(fd,msg,sizeof(Msg));

	if(n_recv == 0)
	{
	    perror("error\n");
	    pthread_exit(NULL);
	}
	switch(msg->action)
	{
	   case 11 :
	   {
	   	reg_sus(msg);
		cmd = menu(msg);
		pass_check(fd,msg,cmd);
	   	break;
	   }

	   case -1:
	   {
		reg_fail();
		cmd = menu(msg);
		pass_check(fd,msg,cmd);
	   	break;
	   }
	   case 12:
	   {
	       log_sus(fd,msg);
	       break;
	       
	   }
	   case -2:
	   {
	       log_fail();
	       cmd = menu(msg);
	       pass_check(fd,msg,cmd);
	       break;
	   }
	   case 13:                //对方聊天窗口未打开时
	   {
	       new_msg(fd,msg);
	       break;
	   }
	   case -3:
	   {
	       break; 
	   }
	   case 14:                //对方聊天窗口已打开
	   {
	       chatwin_recv(fd,msg);
	       break;
	   }
	   case -4:
	   {
	       break;
	   }
	   case 17:                            //管理员登录
	   {
	       adminwin(fd,msg);
	       break;
	   }
	   case 120:
	   {
	       off_line();
	       break;
	   }
	   case 121:
	   {
	       online(fd,msg);
	       break;
	   }
	   case 131:
	   {
	      // newmsg(msg);
	      break;
	   }
	   case 150:
	   {
	       kicked(msg);
	       break;
	   }
	   case 151:
	   {
	       forbid_chat(fd,msg);
	       break;
	   }
	   case 152:
	   {
	       relieve_forbid();
	       chatwin_recv(fd,msg);
	       break;
	   }
	}
    }
}
/*
void send_msg(void *arg)
{
    int fd = *((int *)arg);
    int n_send;

    char buffer[1024];

    while(1)
    {
        memset(buffer,0,sizeof(buffer));
	n_send = write(fd,buffer,sizeof(buffer));

	if(n_send == 0)
	{
	    close(fd);
	    pthread_exit(NULL);
	}
    }
}
*/
int main(int argc,char **argv)
{
    struct online_usr *first = NULL;
    
    int sockfd;
    int ret;
    int menu_rv;
    //int cmd = 0;

    Msg *msg;
    
    msg = (Msg *)malloc(sizeof(Msg));
    pthread_t id;

    struct sockaddr_in serveraddr;
    //struct sockaddr_in cliaddr;

    if(argc != 2)
    {
        printf("usage:client <IP Address>!\n");
	exit(1);
    }
    
    sockfd = socket(AF_INET,SOCK_STREAM,0);

    if(sockfd == -1)
    {
        printf("socket error!\n");
	exit(1);
    }
    bzero(&serveraddr,sizeof(serveraddr));
    serveraddr.sin_family = AF_INET;
    serveraddr.sin_addr.s_addr = inet_addr(argv[1]);
    serveraddr.sin_port = htons(portnumber);

    if(connect(sockfd,(struct sockaddr *)&serveraddr,sizeof(serveraddr)) == -1)
    {
        printf("connect error!\n");
	exit(1);
    }

    pthread_create(&id,NULL,(void *)recv_msg,(void *)&sockfd);

    system("clear");
    memset(msg,0,sizeof(Msg));
    menu_rv = menu(msg);
    //printf("msg->name = %s\n",msg->name);

    //printf("msg->pwd = %s\n",msg->pwd);
    //sleep(3);
    ret = pass_check(sockfd,msg,menu_rv);
    

    if(ret != -1)
    {
        while(1);
        
            //memset(msg,0,sizeof(Msg));

	    //pthread_create(&id,NULL,(void *)send_msg,(void *)&sockfd);
        
    }
    else
    {
        system("clear");
//	menu(msg);
    }

    close(sockfd);
    return 0;
}
