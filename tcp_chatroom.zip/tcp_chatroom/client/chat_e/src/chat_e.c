/*#include <stdio.h>
#include <stdlib.h>
#include <curses.h>*/
#include "../../include/head.h"
int chat_e(int fd,Msg *msg)//chatwin()
{
   
    int x;
    int y;
//    int ch;
    int c;
    int xe;
    int ye;
//    int fd;

    char str[20][20] = {" > y <","(T _ T)","(#> & <#)","(O A O)|||","m(. _ .)m( (_ _) )","(^ _ ^)/(T _ T)"};

    WINDOW *chat_win;     //主聊天框
    WINDOW *w_msg;       //写内容框
    WINDOW *r_msg;       //读信息框
/*    WINDOW *express;     //表情框
    WINDOW *Exit;        //退出按钮
    WINDOW *Enter;       //发送按钮
    //WINDOW *expression;
    */
    WINDOW *sad;         //伤心表情     
    WINDOW *happy;       //开心表情
    WINDOW *mad;         //生气表情
    WINDOW *surprise;    //惊讶表情
    WINDOW *apologize;   //道歉
    WINDOW *comfort;     //安慰

    initscr();
    refresh();
    keypad(stdscr,TRUE);

    curs_set(TRUE);

    chat_win = newwin(20,57,5,20);
    box(chat_win,0,0);
    mvwaddstr(chat_win,1,1,msg->toname);
    
    move(16,21);
    y = 21;
    x = 16;

    r_msg = derwin(chat_win,8,57,3,0);        //r_msg框8行57列，起始位置相对于chatwin框的3行1列
    box(r_msg,0,0);
    
/*    
    w_msg = derwin(chatwin,8,57,10,0);
    box(w_msg,0,0);

    express = derwin(chatwin,3,21,17,0);
    box(express,0,0);
    mvwaddstr(express,1,5,"EXPRESSION");

    Enter = derwin(chatwin,3,21,17,20);
    box(Enter,0,0);
    mvwaddstr(Enter,1,8,"SEND");

    Exit = derwin(chatwin,3,17,17,40);
    box(Exit,0,0);
    mvwaddstr(Exit,1,7,"EXIT");
*/
    wrefresh(chat_win);
    wrefresh(r_msg);
    /*
    wrefresh(w_msg);
    wrefresh(express);
    wrefresh(Enter);
    wrefresh(Exit);*/
    refresh();
   // sleep(3);
   
    while(1)
    {
      //  ch = getch();
	//if(ch ==  KEY_LEFT || ch == KEY_RIGHT || ch == KEY_UP || ch == KEY_DOWN)
	/*
	{
	    if((y == 21) && (x == 16))        // 光标在输入框中
	    {
		    touchwin(w_msg);
		    echo();

		    mvwgetstr(w_msg,1,1,msg->msg);    //stdscr 16,21
		    wrefresh(w_msg);
		    touchwin(chatwin);
      		    ch = getch();
	        switch(ch)
		{
		    case KEY_DOWN:
		    {
		        move(23,35);
			x = 23;
			y = 35;
			refresh();
			break;
		    }
		    case KEY_RIGHT:
		    {
		        move(23,52);
			x = 23;
			y = 52;
			refresh();
			break;
		    }
		}
	    }
	    else if((y == 35) && (x == 23))         //光标在表情框中
	    {
      		ch = getch();
	        switch(ch)
		{
		    case KEY_UP:
		    {
		        move(16,21);
			x = 16;
			y = 21;
			refresh();
			break;
		    }
		    case KEY_RIGHT:
		    {
		        move(23,52);
			x = 23;
			y = 52;
			refresh();
			break;
		    }
		    
		}
	     //光标在表情框中
	
	    if(ch == '\n')  */
	    {
		happy = derwin(chat_win,6,20,10,0);
		box(happy,0,0);
		mvwaddstr(happy,2,7,"> y <");

		sad = derwin(chat_win,6,20,10,19);
		box(sad,0,0);
		mvwaddstr(sad,2,6,"(T _ T)");

                mad = derwin(chat_win,6,19,10,38);
                box(mad,0,0);
		mvwaddstr(mad,2,5,"(#> & <#)");

		surprise = derwin(chat_win,5,20,15,0);
		box(surprise,0,0);
		mvwaddstr(surprise,2,1,"   (O A O)|||     ");
		mvwaddstr(surprise,3,2,"             ");

                apologize = derwin(chat_win,5,20,15,19);
		box(apologize,0,0);
		mvwaddstr(apologize,2,1,"m(. _ .)m( (_ _) )");
		mvwaddstr(apologize,3,1,"                  ");
                
		comfort = derwin(chat_win,5,19,15,38);
		box(comfort,0,0);
		mvwaddstr(comfort,2,1,"  (^ _ ^)/(T _ T)");
		mvwaddstr(comfort,3,1,"                 ");
		refresh();

                move(17,34);     //在happy上
                xe = 17;
		ye = 34;
                wrefresh(happy);
                wrefresh(sad);
                wrefresh(mad);
                wrefresh(surprise);
                wrefresh(apologize);
                wrefresh(comfort);

		refresh();
		
	        while(1)// == KEY_LEFT || ch == KEY_RIGHT || ch == KEY_UP || ch == KEY_DOWN)
                {
		    c = getch();
		    if((xe == 17) && (ye == 34))
		    {   
		        switch(c)
			{
			    case KEY_RIGHT:
			    {
				move(17,53);
				xe = 17;
				ye = 53;
                               
			        refresh();
			        break;
			    }
			    case KEY_DOWN:
			    {
		                move(22,34);
				xe = 22;
				ye = 34;
			        refresh();
			        break;
			    }
			}
		    }
		    if((xe == 17) && (ye == 53))         //sad上
		    {
		        switch(c)
			{
			    case KEY_RIGHT:
			    {
		                move(17,72);
				xe = 17;
				ye = 72;
			        refresh();
			        break;
			    }
			    case KEY_DOWN:
			    {
		                move(22,53);
				xe = 22;
				ye = 53;
			        refresh();
			        break;
			    }
			    case KEY_LEFT:
			    {
			        move(17,34);
				xe = 17;
				ye = 34;
				refresh();
				break;
			    }
			}
		    }
		    if((xe == 17) && (ye == 72))  //mad
		    {
		        switch(c)
			{
			    case KEY_LEFT:
			    {
		                move(17,53);
				xe = 17;
				ye = 53;
			        refresh();
			        break;
			    }
			    case KEY_DOWN:
			    {
		                move(22,72);
				xe = 22;
				ye = 72;
			        refresh();
			        break;
			    }
			}
		    }
		    if((xe == 22) && (ye == 34))  //surprise
		    {
		        //mvwaddstr(chatwin,1,1,"second");
			//wrefresh(chatwin);
		        switch(c)
			{
			    case KEY_RIGHT:
			    {
		                move(22,53);
				xe = 22;
				ye = 53;
			        refresh();
			        break;
			    }
			    case KEY_UP:
			    {
		                move(17,34);
				xe = 17;
				ye = 34;
			        refresh();
			        break;
			    }
		        }
		    }
		    if((xe == 22) && (ye == 53))    //apolo
		    {
		        switch(c)
			{
			    case KEY_RIGHT:
			    {
		                move(22,72);
				xe = 22;
				ye = 72;
			        refresh();
			        break;
			    }
			    case KEY_UP:
			    {
		                move(17,53);
				xe = 17;
				ye = 53;
			        refresh();
			        break;
			    }
			    case KEY_LEFT:
			    {
			        move(22,34);
				xe = 22;
				ye = 34;
				refresh();
				break;
			    }
			}
		    }
		    if((xe == 22) && (ye == 72))     //comfort
		    {
		        switch(c)
			{
			    case KEY_LEFT:
			    {
		                move(22,53);
				xe = 22;
				ye = 53;
			        refresh();
			        break;
			    }
			    case KEY_UP:
			    {
		                move(17,72);
				xe = 17;
				ye = 72;
			        refresh();
			        break;
			    }
		        }
		    }
         	    while(c == '\n')
		    {
		        if(xe == 17 && ye == 34)
			{
                            chat_send_e(fd,msg,0);
			    break;
			}
			else if(xe == 17 && ye == 53)
			{
                            chat_send_e(fd,msg,1);
			    break;
			}
			else if(xe == 17 && ye == 72)
			{
                            chat_send_e(fd,msg,2);
			    break;
			}
			else if(xe == 22 && ye == 34)
			{
                            chat_send_e(fd,msg,3);

			    break;
			}
			else if(xe == 22 && ye == 53)
			{
                            chat_send_e(fd,msg,4);
			    break;
			}
			else if(xe == 22 && ye == 72)
			{
                            chat_send_e(fd,msg,5);
			    break;
			}
			/*
			wclear(happy);
			wclear(sad);
			wclear(mad);
			wclear(surprise);
			wclear(apologize);
			wclear(comfort);

			wrefresh(happy);
			wrefresh(sad);
			wrefresh(mad);
			wrefresh(surprise);
			wrefresh(apologize);
			wrefresh(comfort);

			delwin(happy);
		        delwin(sad);
		        delwin(mad);
		        delwin(surprise);
		        delwin(apologize);
		        delwin(comfort);
		        refresh();
		        move(16,21);
			*/
		    }
	        }
		
		}
	    }
/*	    else if((y == 52) && (x == 23))      //光标在发送框中
	    {
      		ch = getch();
	        switch(ch)
		{
		    case KEY_LEFT:
		    {
		        move(23,35);
			x = 23;
			y = 35;
			refresh();
			break;
		    }
		    case KEY_RIGHT:
		    {
		        move(23,71);
			x = 23;
			y = 71;
			refresh();
			break;
		    }
		    case KEY_UP:
		    {
		        move(16,21);
			x = 16;
			y = 21;
			refresh();
			break;
		    }
		}
		while(ch == '\n')
		{
		    if((msg->msg) != '\0')
		    {
		        msg->action = 3;
		        write(fd,msg,sizeof(Msg));

		        if(write(fd,msg,sizeof(Msg)) == -1)
		        {
		            perror("send error!\n");
			    pthread_exit(NULL);
		        }
			touchwin(r_msg);
			mvwprintw(r_msg,7,15-strlen(msg->msg),"%s",msg->msg);
			touchwin(w_msg);
			wclear(w_msg);
			wrefresh(r_msg);
			refresh();
			break;
                    }  
		}
		
	    }
	    else if((y == 71) && (x == 23))        //光标在退出框中
	    {
      		ch = getch();
	        switch(ch)
		{
		    case KEY_LEFT:
		    {
		        move(23,52);
			x = 23;
			y = 52;
			refresh();
			break;
		    }

		    case KEY_UP:
		    {
		        move(16,21);
			x = 16;
			y = 21;
			refresh();
			break;
		    }
		}
		while(ch == '\n')
		{
                    delwin(chatwin);
                    delwin(r_msg);
                    delwin(w_msg);
                    delwin(express);
                    delwin(Enter);
                    delwin(Exit);

		    refresh();
		    endwin();

		    return 0;
		}
	    }
	}
    }	
*/
//    delwin(chat_win);
//    delwin(r_msg);
//    delwin(w_msg);
//    delwin(express);
//    delwin(Enter);
//    delwin(Exit);

//    refresh();

 //   endwin();
    
    return 0;

}
