#include "../../include/head.h"

int online(int fd,struct message *msg)
{
    int i = 1;
    int x;
    int y;
    int ch;
    //first = NULL;
   // struct online_usr *temp = *first;
    
    WINDOW *in_line;
    WINDOW *head_p;
    WINDOW *friend;
    
    initscr();
    keypad(stdscr,TRUE);
    refresh();

    in_line = newwin(25,23,1,90);
    box(in_line,0,0);
    mvwaddstr(in_line,3,13,msg->name);
    mvwaddstr(in_line,6,1,"Online Friend:");
/*
    for(i = 1;i < 6;i++)
    {
	mvwprintw(in_line,i+8,1,"%s",msg->on_name);
	wrefresh(in_line);
    }
*/    
    head_p = derwin(in_line,4,9,2,2);
    box(head_p,0,0);
    mvwaddstr(head_p,1,2,">");
    mvwaddstr(head_p,2,4,"^");
    mvwaddstr(head_p,1,6,"<");
    wrefresh(in_line);
    wrefresh(head_p);

    friend = derwin(in_line,15,23,7,0);
    box(friend,0,0);
    mvwaddstr(friend,13,1,"X");
    wrefresh(friend);
    move(7,91);
    x = 7;
    y = 91;
    
    refresh();

    for(i = 1;i < 6;i++)
    {
        if((msg->on_name[i]) != '\0');
        {
	    mvwprintw(friend,i,1,"%s",(msg->on_name)[i]);
	    wrefresh(friend);
	}
    }
    refresh();

    touchwin(friend);
    while(1)
    {
        touchwin(friend);
        ch = getch();
        switch(ch)
	{
	    case KEY_UP:
	    {
                move(x-1,y);
		x = x - 1;
		refresh();
		break;
	    }
	    case KEY_DOWN:
	    {
	        move(x+1,y);
		x = x + 1;
		refresh();
		break;
	    }
	    case '\n':
	    {
		if(x == 21 && y == 91)
		{
		    log_sus(fd,msg);
		    return 0;
		}

		strcpy(msg->toname,(msg->on_name)[x - 8]);    //x为当前光标所在行数，减8为对应姓名在数据库中的行数
		chatwin(fd,msg);
		break;
	    }
	}
        
    }


    refresh();
    return 0;
}
