#include "../../include/head.h"

int log_sus(int fd,struct message *msg)//,struct online_usr **first)
{
    int i = 1;
    int x;
    int y;
    int c;
    int ch;
    int ret;
    //first = NULL;
   // struct online_usr *temp = *first;
    
    WINDOW *in_line;
    WINDOW *head_p;
    
    initscr();
    keypad(stdscr,TRUE);
    refresh();

    in_line = newwin(25,23,1,90);
    box(in_line,0,0);
    mvwaddstr(in_line,3,13,msg->name);
    mvwaddstr(in_line,6,1,"Online Friend:");
    mvwaddstr(in_line,1,21,"X");
/*
    for(i = 1;i < 6;i++)
    {
	mvwprintw(in_line,i+8,1,"%s",msg->on_name);
	wrefresh(in_line);
    }
*/    
    //touchwin(in_line);
    refresh();
    head_p = derwin(in_line,4,9,2,2);
    box(head_p,0,0);
    mvwaddstr(head_p,1,2,">");
    mvwaddstr(head_p,2,4,"^");
    mvwaddstr(head_p,1,6,"<");
    wrefresh(in_line);
    wrefresh(head_p);
    move(7,91);
    x = 7;
    y = 91;
    refresh();
    while(1)
    {
        ch = getch();
	
	if(ch == '\n')
        {
	    msg->action = 21;
	    ret = write(fd,msg,sizeof(Msg));
	    
	    if(ret == -1)
	    {
	        perror("  -1 write error!\n");
                sleep(3);
	    }
	    wclear(in_line);
	    wclear(head_p);
	    wrefresh(in_line);
    	    delwin(in_line);
    	    delwin(head_p);

            refresh();
            endwin();
           
	    return 0;
	   
	}
	else if(ch == KEY_UP)
	{
	    move(2,111);
	    x = 2;
	    y = 111;
            
	    c = getch();
	    switch(c)
	    {
	        case KEY_DOWN:
		{
		    move(7,91);
		    x = 7;
		    y = 91;
		    break;
		}
		case '\n':
		{
		    msg->action = 20;
		    write(fd,msg,sizeof(Msg));

    	            delwin(in_line);
    	            delwin(head_p);
		    refresh();
		    endwin();
		    exit(1);
		}
	    }
	}
	
        
    }
   

    refresh();
    
    return 0;
}


log_del(Msg *msg)
{
    
}
