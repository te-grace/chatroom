#include "../../include/head.h"

int log_fail()
{
    WINDOW *log_f;

    initscr();
    refresh();

    log_f = newwin(15,40,7,40);
    box(log_f,0,0);
    mvwaddstr(log_f,5,13,"login error!");
    mvwaddstr(log_f,7,3,"name not exist or password wrong");
    mvwaddstr(log_f,9,10,"please login again");
    
    wrefresh(log_f);
    sleep(3);
    delwin(log_f);

    endwin();
    
    return 0;
}
